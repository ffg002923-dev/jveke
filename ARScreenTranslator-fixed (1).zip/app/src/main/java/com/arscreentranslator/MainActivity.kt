package com.arscreentranslator

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private val captureRequest = 4102
    private lateinit var mode: Spinner
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 36, 28, 24); setBackgroundColor(Color.rgb(16,19,34)) }
        val title = TextView(this).apply { text = "AR Screen Translator"; textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 12, 0, 8) }
        val subtitle = TextView(this).apply { text = "ترجمة الشاشة إلى العربية مباشرة"; textSize = 17f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 0, 0, 28) }
        mode = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("تلقائي بدون إنترنت (على الجهاز)", "ترجمة عبر الإنترنت")) }
        val note = TextView(this).apply { text = "سيطلب التطبيق إذن مشاركة الشاشة وإذن الظهور فوق التطبيقات. يمكنك إيقاف المشاركة من إشعار أندرويد."; setTextColor(Color.LTGRAY); textSize = 14f; setPadding(0,20,0,20) }
        val start = Button(this).apply { text = "ابدأ الترجمة"; setOnClickListener { begin() } }
        root.addView(title); root.addView(subtitle)
        root.addView(mode, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 56))
        root.addView(note); root.addView(start, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 58))
        setContentView(root)
    }
    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "فعّل الظهور فوق التطبيقات ثم اضغط ابدأ مرة أخرى", Toast.LENGTH_LONG).show(); return
        }
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
    }
    @Deprecated("Legacy callback retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, ScreenTranslateService::class.java).apply {
                putExtra(ScreenTranslateService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenTranslateService.EXTRA_DATA, data)
                putExtra(ScreenTranslateService.EXTRA_ONLINE, mode.selectedItemPosition == 1)
            }
            startForegroundService(intent)
            Toast.makeText(this, "بدأت الترجمة. افتح اللعبة أو التطبيق الآن.", Toast.LENGTH_LONG).show()
        }
    }
}

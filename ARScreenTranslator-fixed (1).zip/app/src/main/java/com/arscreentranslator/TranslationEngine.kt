package com.arscreentranslator

import com.google.mlkit.nl.translate.*
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

/** Arabic translation: on-device ML Kit (downloads its model once) or online LibreTranslate endpoint. */
class TranslationEngine(private val online: Boolean) {
    private val options = TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.ARABIC).build()
    private val translator = Translation.getClient(options)
    fun prepare(onReady: (Boolean) -> Unit) {
        if (online) { onReady(true); return }
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).addOnSuccessListener { onReady(true) }.addOnFailureListener { onReady(false) }
    }
    fun translate(text: String, callback: (String?) -> Unit) {
        if (!online) {
            translator.translate(text).addOnSuccessListener(callback).addOnFailureListener { callback(null) }
            return
        }
        Thread {
            var result: String? = null
            try {
                // Public demo endpoint; production deployments should configure a trusted endpoint/API key.
                val conn = (URL("https://translate.argosopentech.com/translate").openConnection() as HttpURLConnection)
                conn.requestMethod = "POST"; conn.connectTimeout = 7000; conn.readTimeout = 7000; conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                val body = JSONObject().put("q", text).put("source", "en").put("target", "ar").put("format", "text").toString()
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                if (conn.responseCode in 200..299) result = JSONObject(conn.inputStream.bufferedReader().readText()).optString("translatedText")
                conn.disconnect()
            } catch (_: Exception) { }
            callback(result)
        }.start()
    }
    fun close() = translator.close()
}

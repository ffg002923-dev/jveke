package com.arscreentranslator

import android.app.*
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.FrameLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class ScreenTranslateService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"; const val EXTRA_DATA = "data"; const val EXTRA_ONLINE = "online"
        private const val CHANNEL = "ar_translate_channel"
    }
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: TranslationOverlay? = null
    private var busy = false
    private var lastFrame = 0L
    private lateinit var engine: TranslationEngine
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var screenW = 0; private var screenH = 0; private var density = 1

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForeground(7, Notification.Builder(this, CHANNEL).setContentTitle("AR Screen Translator").setContentText("ترجمة الشاشة مفعّلة").setSmallIcon(android.R.drawable.ic_menu_search).build())
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        engine = TranslationEngine(intent.getBooleanExtra(EXTRA_ONLINE, false))
        engine.prepare { ready ->
            if (ready) startCapture(resultCode, data) else { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        }
        return START_NOT_STICKY
    }
    private fun startCapture(code: Int, data: Intent) {
        val dm = resources.displayMetrics; screenW = dm.widthPixels; screenH = dm.heightPixels; density = dm.densityDpi
        overlay = TranslationOverlay(this, screenW, screenH).also { it.show() }
        reader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                display?.release(); display = null
                reader?.close(); reader = null
                overlay?.hide(); overlay = null
                stopSelf()
            }
        }, Handler(Looper.getMainLooper()))
        display = projection?.createVirtualDisplay("ARScreenTranslator", screenW, screenH, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
        reader?.setOnImageAvailableListener({ r ->
            val now = System.currentTimeMillis()
            if (busy || now - lastFrame < 1200) { r.acquireLatestImage()?.close(); return@setOnImageAvailableListener }
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            busy = true; lastFrame = now
            process(image)
        }, Handler(Looper.getMainLooper()))
    }
    private fun process(image: Image) {
        try {
            val bitmap = imageToBitmap(image); image.close()
            recognizer.process(InputImage.fromBitmap(bitmap, 0)).addOnSuccessListener { result ->
                val blocks = result.textBlocks.filter { it.text.any { c -> c.isLetter() } && it.text.none { c -> c.code in 0x0600..0x06ff } }
                val out = mutableListOf<TranslationOverlay.Item>()
                fun next(i: Int) {
                    if (i >= blocks.size) { overlay?.update(out); bitmap.recycle(); busy = false; return }
                    val b = blocks[i]; val rect = b.boundingBox
                    if (rect == null || b.text.length > 180) { next(i+1); return }
                    engine.translate(b.text) { translated ->
                        if (translated != null) out.add(TranslationOverlay.Item(Rect(rect), translated))
                        next(i+1)
                    }
                }
                next(0)
            }.addOnFailureListener { bitmap.recycle(); busy = false }
        } catch (_: Exception) { try { image.close() } catch (_: Exception) {}; busy = false }
    }
    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]; val buffer = plane.buffer; val pixelStride = plane.pixelStride; val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * screenW
        val padded = Bitmap.createBitmap(screenW + rowPadding / pixelStride, screenH, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, screenW, screenH); padded.recycle(); return cropped
    }
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL, "Screen translation", NotificationManager.IMPORTANCE_LOW))
    }
    override fun onDestroy() {
        display?.release(); reader?.close(); projection?.stop(); overlay?.hide(); recognizer.close()
        if (::engine.isInitialized) engine.close()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null

    class TranslationOverlay(private val context: Context, private val w: Int, private val h: Int) {
        data class Item(val bounds: Rect, val text: String)
        private val window = WindowManager.LayoutParams(w, h, if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        private val view = OverlayView(context)
        private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        fun show() { wm.addView(view, window) }
        fun update(items: List<Item>) { view.items = items; view.postInvalidate() }
        fun hide() { try { wm.removeView(view) } catch (_: Exception) {} }
        private class OverlayView(context: Context) : View(context) {
            var items: List<Item> = emptyList()
            private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(22, 25, 38); style = Paint.Style.FILL }
            private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 30f; typeface = Typeface.create("sans-serif", Typeface.BOLD); textAlign = Paint.Align.RIGHT }
            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                val sx = width.toFloat() / (resources.displayMetrics.widthPixels)
                val sy = height.toFloat() / (resources.displayMetrics.heightPixels)
                items.forEach { item ->
                    val r = RectF(item.bounds.left*sx, item.bounds.top*sy, item.bounds.right*sx, item.bounds.bottom*sy)
                    val pad = 5f; canvas.drawRoundRect(RectF(r.left-pad, r.top-pad, r.right+pad, r.bottom+pad), 5f, 5f, bg)
                    val size = (r.height()*0.72f).coerceIn(18f, 42f); fg.textSize = size
                    val words = item.text.take(140)
                    canvas.drawText(words, r.right, r.bottom - maxOf(2f, (r.height()-size)/2f), fg)
                }
            }
        }
    }
}

# AR Screen Translator (Android native)

A native Kotlin Android prototype that captures the screen with Android MediaProjection, detects Latin-script text with ML Kit Text Recognition, translates English to Arabic, and draws Arabic translations in a non-touchable overlay.

## Build a real APK

### GitHub Actions (no Android Studio required on your computer)
1. Create a private or public GitHub repository and upload the contents of this folder.
2. Open **Actions** → **Build Android APK** → **Run workflow**.
3. When it finishes, open the run's **Artifacts** section and download `ARScreenTranslator-debug-apk`.
4. Extract the artifact; install `app-debug.apk` on your Android phone. Android may ask you to allow installation from that source.

### Android Studio
Open this folder as a project. Use JDK 17 and Android Gradle Plugin 8.7.3; compile SDK 35. Run `gradle assembleDebug` (or use Android Studio's Gradle sync/build controls).

## First run
- Grant **Display over other apps** permission.
- Tap **Start translation** and approve Android's screen-capture prompt.
- Select offline (ML Kit downloads its English→Arabic model once) or online (uses a public demo LibreTranslate endpoint; availability and privacy are not guaranteed).
- Stop screen sharing from Android's screen-capture notification / system controls.

## Important limitations
- This is a functional prototype, not a guaranteed game-localization replacement. Android does not let ordinary apps rewrite another app's rendered pixels. The app places a best-effort Arabic cover over detected English text; background reconstruction, exact font matching, multi-line layout, game frame rates, protected/DRM screens, and some games may not work reliably.
- The current OCR model recognizes Latin-script text. Arabic source text is ignored. Small, animated, stylized, or low-contrast game text may be missed.
- Offline translation requires downloading Google's ML Kit translation model and uses on-device processing afterward. Online translation sends recognized text to the configured public endpoint; do not use it for private content. Replace the demo endpoint with a trusted provider before public release.
- A debug APK is unsigned for Play Store distribution. A release build needs a signing key and secure key handling.
- Test on the target Android version and device. Screen capture and overlay permissions are explicitly controlled by Android and the user.
